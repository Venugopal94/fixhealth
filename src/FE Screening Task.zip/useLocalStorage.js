// import './App.css';
// import React,{useState} from 'react';
// //import useLocalStorage from './useLocalStorage';

// function getSavedValue(key,initialValue)
// {
// const savedValue = JSON.parse(localStorage.getItem(key));
// if(savedValue)
// {
//     return savedValue
// }
// else{
//     return initialValue;
// }
// }
// {
//     let [value,setValue]=useState('');
// }